import React from 'react';
import { Outlet } from 'react-router-dom';
import { ToastContainer } from '../components/common/ToastContainer';
import { Sparkles } from 'lucide-react';

export const AuthLayout: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#080F1D] flex flex-col justify-center items-center p-6 relative overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-[#2585F5]/10 to-[#36B8F5]/10 blur-[140px] pointer-events-none rounded-full" />

      {/* Brand header */}
      <div className="flex items-center gap-3 mb-8 z-10">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#2585F5] to-[#36B8F5] flex items-center justify-center shadow-xl shadow-[#2585F5]/30">
          <Sparkles className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">
            VIDEO TRANSLATOR <span className="text-[#36B8F5]">AI PRO</span>
          </h1>
          <p className="text-xs text-slate-400 font-medium">Enterprise Multilingual Dubbing & Video Studio</p>
        </div>
      </div>

      <div className="w-full max-w-md bg-[#132238] border border-[#1E3250] rounded-2xl p-8 shadow-2xl relative z-10 backdrop-blur-md">
        <Outlet />
      </div>

      <ToastContainer />
    </div>
  );
};
