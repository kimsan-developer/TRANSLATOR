import React, { useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from '../components/common/Sidebar';
import { Navbar } from '../components/common/Navbar';
import { ToastContainer } from '../components/common/ToastContainer';
import { getSocket } from '../services/socket';
import { toast } from '../stores/toastStore';
import { useProjectStore } from '../stores/projectStore';
import { api } from '../services/api';

export const MainLayout: React.FC = () => {
  const { currentProject, setCurrentProject } = useProjectStore();

  useEffect(() => {
    const socket = getSocket();

    socket.on('job:completed', async (data) => {
      toast.success(`Job completed successfully!`, 'Task Finished');
      // Refresh current project if matches
      if (currentProject) {
        try {
          const res = await api.get(`/projects/${currentProject._id}`);
          if (res.data.success) {
            setCurrentProject(res.data.project);
          }
        } catch {}
      }
    });

    socket.on('job:failed', (data) => {
      toast.error(data.error || 'A processing job encountered an error', 'Task Failed');
    });

    return () => {
      socket.off('job:completed');
      socket.off('job:failed');
    };
  }, [currentProject, setCurrentProject]);

  return (
    <div className="flex min-h-screen bg-[#080F1D] text-[#F1F5F9]">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Navbar />
        <main className="flex-1 p-8 overflow-y-auto max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
      <ToastContainer />
    </div>
  );
};
