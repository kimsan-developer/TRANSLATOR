import { create } from 'zustand';
import { Project } from '../types';

interface ProjectState {
  currentProject: Project | null;
  projects: Project[];
  setCurrentProject: (project: Project | null) => void;
  setProjects: (projects: Project[]) => void;
  updateProjectInList: (project: Project) => void;
}

export const useProjectStore = create<ProjectState>((set) => ({
  currentProject: null,
  projects: [],
  setCurrentProject: (project) => set({ currentProject: project }),
  setProjects: (projects) => set({ projects }),
  updateProjectInList: (updated) =>
    set((state) => ({
      projects: state.projects.map((p) => (p._id === updated._id ? updated : p)),
      currentProject: state.currentProject?._id === updated._id ? updated : state.currentProject,
    })),
}));
