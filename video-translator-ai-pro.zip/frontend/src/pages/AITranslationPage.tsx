import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useProjectStore } from '../stores/projectStore';
import { toast } from '../stores/toastStore';
import { Languages, ArrowRight, RefreshCw, Sparkles, Check, Loader2 } from 'lucide-react';

export const AITranslationPage: React.FC = () => {
  const { currentProject } = useProjectStore();
  const [origSub, setOrigSub] = useState<any>(null);
  const [transSub, setTransSub] = useState<any>(null);
  const [targetLanguage, setTargetLanguage] = useState('km');
  const [provider, setProvider] = useState('gemini');
  const [style, setStyle] = useState<'formal' | 'casual'>('formal');
  const [translating, setTranslating] = useState(false);

  const fetchSubs = async () => {
    if (!currentProject) return;
    try {
      const [origRes, transRes] = await Promise.all([
        api.get(`/subtitles?projectId=${currentProject._id}&type=original`).catch(() => ({ data: {} })),
        api.get(`/subtitles?projectId=${currentProject._id}&type=translated`).catch(() => ({ data: {} })),
      ]);
      if (origRes.data?.success) setOrigSub(origRes.data.subtitle);
      if (transRes.data?.success) setTransSub(transRes.data.subtitle);
    } catch {}
  };

  useEffect(() => {
    fetchSubs();
  }, [currentProject]);

  const handleTranslate = async () => {
    if (!currentProject) return;
    setTranslating(true);
    try {
      const res = await api.post('/translation/start', {
        projectId: currentProject._id,
        targetLanguage,
        provider,
        style,
      });
      if (res.data.success) {
        toast.success('Translation started in background queue');
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Translation failed');
    } finally {
      setTranslating(false);
    }
  };

  if (!currentProject) {
    return (
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-12 text-center max-w-xl mx-auto my-12">
        <Languages className="w-12 h-12 text-[#2585F5] mx-auto mb-3" />
        <h2 className="text-xl font-bold text-white">No Project Selected</h2>
        <p className="text-xs text-slate-400 mt-2">Select a project to view and translate subtitles.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E3250]">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Languages className="w-6 h-6 text-[#2585F5]" /> AI Translation Studio
          </h1>
          <p className="text-xs text-slate-400 mt-1">Context-aware multilingual translation</p>
        </div>

        <button
          onClick={handleTranslate}
          disabled={translating || !origSub}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-2 disabled:opacity-40"
        >
          {translating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          Translate Subtitles
        </button>
      </div>

      {/* Settings Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Target Language</label>
          <select
            value={targetLanguage}
            onChange={(e) => setTargetLanguage(e.target.value)}
            className="w-full px-4 py-2 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
          >
            <option value="km">Khmer (km)</option>
            <option value="en">English (en)</option>
            <option value="th">Thai (th)</option>
            <option value="vi">Vietnamese (vi)</option>
            <option value="zh">Chinese (zh)</option>
            <option value="ja">Japanese (ja)</option>
            <option value="fr">French (fr)</option>
            <option value="es">Spanish (es)</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">AI Provider</label>
          <select
            value={provider}
            onChange={(e) => setProvider(e.target.value)}
            className="w-full px-4 py-2 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
          >
            <option value="gemini">Google Gemini 1.5 Flash</option>
            <option value="openai">OpenAI GPT-4o-mini</option>
            <option value="local">Local Translation Adapter</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Style</label>
          <select
            value={style}
            onChange={(e) => setStyle(e.target.value as any)}
            className="w-full px-4 py-2 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
          >
            <option value="formal">Formal / Neutral</option>
            <option value="casual">Casual / Conversational</option>
          </select>
        </div>
      </div>

      {/* Side-by-Side Subtitles View */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Original */}
        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-xl flex flex-col">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#1E3250]">
            <h3 className="text-xs font-bold text-slate-300 uppercase">Original Subtitles</h3>
            <span className="text-xs text-slate-400 font-mono">{origSub?.segments?.length || 0} items</span>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
            {origSub?.segments?.map((s: any) => (
              <div key={s.id} className="p-3 rounded-xl bg-[#0D1728] border border-[#1E3250]">
                <div className="text-[10px] font-mono text-[#36B8F5] mb-1">
                  [{s.start.toFixed(2)}s - {s.end.toFixed(2)}s]
                </div>
                <div className="text-xs text-slate-200">{s.text}</div>
              </div>
            )) || <div className="text-xs text-slate-400 text-center py-8">No original subtitles</div>}
          </div>
        </div>

        {/* Translated */}
        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-xl flex flex-col">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#1E3250]">
            <h3 className="text-xs font-bold text-emerald-400 uppercase">Translated Subtitles</h3>
            <span className="text-xs text-slate-400 font-mono">{transSub?.segments?.length || 0} items</span>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
            {transSub?.segments?.map((s: any) => (
              <div key={s.id} className="p-3 rounded-xl bg-[#0D1728] border border-emerald-500/20">
                <div className="text-[10px] font-mono text-emerald-400 mb-1">
                  [{s.start.toFixed(2)}s - {s.end.toFixed(2)}s]
                </div>
                <div className="text-xs text-white font-medium">{s.text}</div>
              </div>
            )) || <div className="text-xs text-slate-400 text-center py-8">Translation not yet run</div>}
          </div>
        </div>
      </div>
    </div>
  );
};
