import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { VoiceProfile } from '../types';
import { toast } from '../stores/toastStore';
import { Modal } from '../components/common/Modal';
import { UserCheck, Plus, Trash2, ShieldAlert, Mic, AudioWaveform, Loader2 } from 'lucide-react';

export const VoiceCloningPage: React.FC = () => {
  const [profiles, setProfiles] = useState<VoiceProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [language, setLanguage] = useState('en');
  const [gender, setGender] = useState<'male' | 'female' | 'neutral'>('neutral');
  const [provider, setProvider] = useState('local');
  const [consentAgreed, setConsentAgreed] = useState(false);
  const [creating, setCreating] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const fetchProfiles = async () => {
    try {
      const res = await api.get('/voice-clones');
      if (res.data.success) {
        setProfiles(res.data.profiles);
      }
    } catch {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfiles();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      toast.error('Voice audio sample file is required');
      return;
    }
    if (!consentAgreed) {
      toast.error('Explicit consent authorization must be granted');
      return;
    }

    setCreating(true);
    const formData = new FormData();
    formData.append('voiceSample', selectedFile);
    formData.append('name', name);
    formData.append('language', language);
    formData.append('gender', gender);
    formData.append('provider', provider);
    formData.append('consentAgreed', 'true');

    try {
      const res = await api.post('/voice-clones/create', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      if (res.data.success) {
        toast.success('Voice profile created!');
        setIsModalOpen(false);
        setName('');
        setSelectedFile(null);
        setConsentAgreed(false);
        fetchProfiles();
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Voice cloning failed');
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this voice profile?')) return;
    try {
      const res = await api.delete(`/voice-clones/${id}`);
      if (res.data.success) {
        toast.success('Profile deleted');
        setProfiles(profiles.filter((p) => p._id !== id));
      }
    } catch {
      toast.error('Failed to delete profile');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E3250]">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <UserCheck className="w-6 h-6 text-[#2585F5]" /> Voice Cloning Studio
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Create personalized voice profiles with strict consent and authorization protocols
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" /> Create Voice Profile
        </button>
      </div>

      {/* Profiles Grid */}
      {loading ? (
        <div className="flex justify-center p-12">
          <Loader2 className="w-8 h-8 text-[#2585F5] animate-spin" />
        </div>
      ) : profiles.length === 0 ? (
        <div className="bg-[#132238] border border-dashed border-[#1E3250] rounded-2xl p-12 text-center">
          <Mic className="w-12 h-12 text-slate-400 mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-white">No custom voice profiles</h3>
          <p className="text-xs text-slate-400 mt-1">Upload a clear 30-60 second audio sample to clone a voice</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {profiles.map((p) => (
            <div key={p._id} className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold uppercase text-[#36B8F5] px-2 py-0.5 rounded bg-[#2585F5]/20">
                    {p.gender}
                  </span>
                  <button
                    onClick={() => handleDelete(p._id)}
                    className="text-slate-400 hover:text-rose-400 p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <h3 className="font-bold text-white text-base mt-2">{p.name}</h3>
                <p className="text-xs text-slate-400 mt-0.5">Language: {p.language.toUpperCase()}</p>
                <div className="mt-3">
                  <audio controls src={p.samplePath} className="w-full h-8" />
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-[#1E3250] text-[11px] text-emerald-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400" /> Authorized Voice Sample Verified
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Create Authorized Voice Profile">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Profile Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Alex Studio Voice"
              className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Language</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
              >
                <option value="en">English (en)</option>
                <option value="km">Khmer (km)</option>
                <option value="th">Thai (th)</option>
                <option value="vi">Vietnamese (vi)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
              >
                <option value="neutral">Neutral</option>
                <option value="female">Female</option>
                <option value="male">Male</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">
              Audio Sample (WAV, MP3, M4A) *
            </label>
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              required
              onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
              className="w-full text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-[#1E3250] file:text-white hover:file:bg-[#2585F5]"
            />
          </div>

          {/* Consent Checkbox */}
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30">
            <div className="flex items-start gap-2.5">
              <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-amber-200">
                  <input
                    type="checkbox"
                    checked={consentAgreed}
                    onChange={(e) => setConsentAgreed(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2585F5]"
                  />
                  I confirm that I own or have explicit written authorization to clone this voice.
                </label>
                <p className="text-[11px] text-amber-300/70 mt-1">
                  Unauthorized voice cloning without consent is strictly prohibited.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={creating || !consentAgreed || !selectedFile}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-2 disabled:opacity-40"
            >
              {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Profile'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
