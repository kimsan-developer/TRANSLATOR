import React, { useState } from 'react';
import { useAuthStore } from '../stores/authStore';
import { api } from '../services/api';
import { toast } from '../stores/toastStore';
import { User, Mail, Shield, Save, Loader2 } from 'lucide-react';

export const UserProfilePage: React.FC = () => {
  const { user, updateUser } = useAuthStore();
  const [name, setName] = useState(user?.name || '');
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await api.put('/auth/profile', { name });
      if (res.data.success) {
        updateUser({ name });
        toast.success('Profile details updated!');
      }
    } catch {
      toast.error('Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl mx-auto">
      <div>
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <User className="w-6 h-6 text-[#2585F5]" /> User Profile
        </h1>
        <p className="text-xs text-slate-400 mt-1">Manage personal details, credentials, and studio preferences</p>
      </div>

      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl space-y-6">
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Display Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-sm text-white focus:outline-none focus:border-[#2585F5]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Email Address</label>
            <input
              type="email"
              disabled
              value={user?.email || ''}
              className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D]/50 border border-[#1E3250] text-sm text-slate-400 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Role & Permissions</label>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#0D1728] border border-[#1E3250] text-xs font-bold text-[#36B8F5] uppercase">
              <Shield className="w-4 h-4" /> {user?.role || 'User'}
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-2"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
