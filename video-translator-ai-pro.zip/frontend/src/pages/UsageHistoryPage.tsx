import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { UsageRecord } from '../types';
import { History, TrendingUp, Clock, FileText, DollarSign, Loader2 } from 'lucide-react';

export const UsageHistoryPage: React.FC = () => {
  const [records, setRecords] = useState<UsageRecord[]>([]);
  const [totals, setTotals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsage = async () => {
      try {
        const res = await api.get('/history');
        if (res.data.success) {
          setRecords(res.data.records);
          setTotals(res.data.totals || []);
        }
      } catch {
      } finally {
        setLoading(false);
      }
    };
    fetchUsage();
  }, []);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <History className="w-6 h-6 text-[#2585F5]" /> Usage History & Analytics
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Detailed processing metrics, transcribed audio duration, and estimated cloud AI costs
        </p>
      </div>

      {/* Metrics Breakdown */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 uppercase font-semibold">
            <span>Total Operations</span>
            <TrendingUp className="w-4 h-4 text-[#36B8F5]" />
          </div>
          <div className="text-2xl font-black text-white mt-2">{records.length}</div>
        </div>

        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 uppercase font-semibold">
            <span>Audio Processed</span>
            <Clock className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-white mt-2">
            {records.reduce((acc, r) => acc + (r.durationSeconds || 0), 0).toFixed(0)}s
          </div>
        </div>

        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 uppercase font-semibold">
            <span>Estimated AI Cost</span>
            <DollarSign className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-white mt-2">
            ${records.reduce((acc, r) => acc + (r.costEstimate || 0), 0).toFixed(4)}
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0D1728] text-slate-400 uppercase font-semibold border-b border-[#1E3250]">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Feature</th>
                <th className="py-3 px-4">Provider</th>
                <th className="py-3 px-4">Units / Duration</th>
                <th className="py-3 px-4">Cost Est.</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E3250]">
              {records.map((r) => (
                <tr key={r._id} className="hover:bg-[#0D1728]/40">
                  <td className="py-3 px-4 text-slate-300">
                    {new Date(r.timestamp).toLocaleString()}
                  </td>
                  <td className="py-3 px-4 font-semibold text-white uppercase">{r.feature}</td>
                  <td className="py-3 px-4 text-slate-400">{r.provider}</td>
                  <td className="py-3 px-4 font-mono text-slate-300">
                    {r.durationSeconds ? `${Math.round(r.durationSeconds)}s` : r.characterCount ? `${r.characterCount} chars` : '-'}
                  </td>
                  <td className="py-3 px-4 font-mono text-emerald-400">
                    ${r.costEstimate ? r.costEstimate.toFixed(4) : '0.0000'}
                  </td>
                  <td className="py-3 px-4 text-emerald-400 uppercase font-bold text-[10px]">
                    {r.status}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
