import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { toast } from '../stores/toastStore';
import { AudioWaveform, Play, Download, Volume2, Sparkles, Sliders, Loader2 } from 'lucide-react';

export const AIVoiceGeneratorPage: React.FC = () => {
  const [voices, setVoices] = useState<any[]>([]);
  const [selectedVoice, setSelectedVoice] = useState('en-US-JennyNeural');
  const [text, setText] = useState('Welcome to Video Translator AI Pro. Experience natural, multilingual neural speech synthesis.');
  const [targetLang, setTargetLang] = useState('en');
  const [rate, setRate] = useState('+0%');
  const [pitch, setPitch] = useState('+0Hz');
  const [loading, setLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  useEffect(() => {
    const fetchVoices = async () => {
      try {
        const res = await api.get('/tts/voices');
        if (res.data.success) {
          setVoices(res.data.voices);
        }
      } catch {}
    };
    fetchVoices();
  }, []);

  const handleSynthesize = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setAudioUrl(null);
    try {
      const res = await api.post('/tts/preview', {
        text,
        voiceId: selectedVoice,
        targetLang,
        provider: 'edge-tts',
      });
      if (res.data.success) {
        setAudioUrl(res.data.audioUrl);
        toast.success('Speech generated successfully!');
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'TTS synthesis failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <AudioWaveform className="w-6 h-6 text-[#2585F5]" /> AI Voice Generator Playground
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          High-fidelity multilingual neural voices (Khmer, English, Thai, Vietnamese, Japanese, Chinese, French, and more)
        </p>
      </div>

      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl space-y-6">
        {/* Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Select Neural Voice</label>
            <select
              value={selectedVoice}
              onChange={(e) => setSelectedVoice(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
            >
              {voices.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name} ({v.gender}, {v.lang})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Speaking Rate</label>
            <select
              value={rate}
              onChange={(e) => setRate(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
            >
              <option value="-20%">Slow (-20%)</option>
              <option value="+0%">Normal (1.0x)</option>
              <option value="+15%">Fast (+15%)</option>
              <option value="+30%">Very Fast (+30%)</option>
            </select>
          </div>
        </div>

        {/* Text Input */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Text to Synthesize</label>
          <textarea
            rows={4}
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="w-full p-4 rounded-xl bg-[#080F1D] border border-[#1E3250] text-sm text-white focus:outline-none focus:border-[#2585F5]"
            placeholder="Enter text to speak..."
          />
        </div>

        <button
          onClick={handleSynthesize}
          disabled={loading || !text.trim()}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center justify-center gap-2"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          Generate Speech Audio
        </button>

        {/* Player Result */}
        {audioUrl && (
          <div className="p-4 rounded-xl bg-[#0D1728] border border-[#2585F5]/40 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <Volume2 className="w-6 h-6 text-[#36B8F5] shrink-0" />
              <audio controls src={audioUrl} autoPlay className="w-full sm:w-72 h-9" />
            </div>
            <a
              href={audioUrl}
              download="synthesized_speech.mp3"
              className="px-4 py-2 rounded-xl bg-[#1E3250] hover:bg-[#2585F5] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0"
            >
              <Download className="w-3.5 h-3.5" /> Download Audio
            </a>
          </div>
        )}
      </div>
    </div>
  );
};
