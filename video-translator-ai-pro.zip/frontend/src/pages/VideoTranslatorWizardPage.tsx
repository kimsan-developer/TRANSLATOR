import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { useProjectStore } from '../stores/projectStore';
import { toast } from '../stores/toastStore';
import { getSocket } from '../services/socket';
import {
  Upload,
  Mic,
  Languages,
  AudioWaveform,
  CheckCircle2,
  Sparkles,
  Download,
  Play,
  RotateCcw,
  Sliders,
  Loader2,
  FileVideo,
  Volume2,
} from 'lucide-react';

export const VideoTranslatorWizardPage: React.FC = () => {
  const { currentProject, setCurrentProject } = useProjectStore();
  const [projectData, setProjectData] = useState<any>(null);
  const [step, setStep] = useState(1);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [processing, setProcessing] = useState(false);
  const [currentJob, setCurrentJob] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Configuration states
  const [whisperModel, setWhisperModel] = useState('base');
  const [transcriptionLang, setTranscriptionLang] = useState('auto');
  const [translationProvider, setTranslationProvider] = useState('gemini');
  const [translationStyle, setTranslationStyle] = useState<'formal' | 'casual'>('formal');
  const [targetLang, setTargetLang] = useState('km');
  const [voiceGender, setVoiceGender] = useState<'female' | 'male'>('female');
  const [selectedVoice, setSelectedVoice] = useState('km-KH-SreymomNeural');
  const [burnSubtitles, setBurnSubtitles] = useState(true);
  const [replaceAudio, setReplaceAudio] = useState(true);
  const [exportFormat, setExportFormat] = useState('mp4');
  const [exportResolution, setExportResolution] = useState('1080p');

  // Load project details
  const fetchProjectDetails = async () => {
    if (!currentProject) return;
    try {
      const res = await api.get(`/projects/${currentProject._id}`);
      if (res.data.success) {
        setProjectData(res.data);
        if (res.data.project.currentStep) {
          setStep(res.data.project.currentStep);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchProjectDetails();
  }, [currentProject]);

  // Socket listener for real-time progress
  useEffect(() => {
    const socket = getSocket();
    if (currentProject) {
      socket.emit('join:project', currentProject._id);
    }

    const onProgress = (data: any) => {
      setCurrentJob((prev: any) => ({ ...prev, progress: data.progress, currentStep: data.currentStep }));
    };

    const onCompleted = (data: any) => {
      setProcessing(false);
      fetchProjectDetails();
      toast.success('Step completed successfully!');
    };

    const onFailed = (data: any) => {
      setProcessing(false);
      toast.error(data.error || 'Operation failed');
    };

    socket.on('job:progress', onProgress);
    socket.on('job:completed', onCompleted);
    socket.on('job:failed', onFailed);

    return () => {
      socket.off('job:progress', onProgress);
      socket.off('job:completed', onCompleted);
      socket.off('job:failed', onFailed);
    };
  }, [currentProject]);

  // Handle Video Upload
  const handleFileUpload = async (file: File) => {
    if (!currentProject) {
      toast.error('Please create or select a project first');
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    const formData = new FormData();
    formData.append('video', file);
    formData.append('projectId', currentProject._id);

    try {
      const res = await api.post('/videos/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          if (progressEvent.total) {
            setUploadProgress(Math.round((progressEvent.loaded * 100) / progressEvent.total));
          }
        },
      });

      if (res.data.success) {
        toast.success('Video uploaded & probed successfully!');
        setStep(2);
        fetchProjectDetails();
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  // Step 2: Start Transcription
  const handleStartTranscription = async () => {
    if (!currentProject) return;
    setProcessing(true);
    setCurrentJob({ progress: 5, currentStep: 'Starting Faster-Whisper transcription...' });

    try {
      const res = await api.post('/transcription/start', {
        projectId: currentProject._id,
        language: transcriptionLang,
        model: whisperModel,
        provider: 'whisper',
      });
      if (res.data.success) {
        toast.info('Transcription queued in background queue');
      }
    } catch (err: any) {
      setProcessing(false);
      toast.error(err.response?.data?.error || 'Failed to start transcription');
    }
  };

  // Step 3: Start Translation
  const handleStartTranslation = async () => {
    if (!currentProject) return;
    setProcessing(true);
    setCurrentJob({ progress: 10, currentStep: 'Starting AI translation...' });

    try {
      const res = await api.post('/translation/start', {
        projectId: currentProject._id,
        targetLanguage: targetLang,
        sourceLanguage: projectData?.project?.sourceLanguage || 'auto',
        provider: translationProvider,
        style: translationStyle,
      });
      if (res.data.success) {
        toast.info('Translation job queued');
      }
    } catch (err: any) {
      setProcessing(false);
      toast.error(err.response?.data?.error || 'Failed to start translation');
    }
  };

  // Step 4: Start AI Dubbing
  const handleStartDubbing = async () => {
    if (!currentProject) return;
    setProcessing(true);
    setCurrentJob({ progress: 10, currentStep: 'Generating multilingual speech...' });

    try {
      const res = await api.post('/tts/dub', {
        projectId: currentProject._id,
        voiceId: selectedVoice,
        gender: voiceGender,
        provider: 'edge-tts',
      });
      if (res.data.success) {
        toast.info('AI Dubbing synthesis queued');
      }
    } catch (err: any) {
      setProcessing(false);
      toast.error(err.response?.data?.error || 'Failed to start dubbing');
    }
  };

  // Step 5: Start Video Export
  const handleStartExport = async () => {
    if (!currentProject) return;
    setProcessing(true);
    setCurrentJob({ progress: 10, currentStep: 'Encoding final video with FFmpeg...' });

    try {
      const res = await api.post('/export/start', {
        projectId: currentProject._id,
        format: exportFormat,
        resolution: exportResolution,
        burnSubtitles,
        replaceAudio,
        originalAudioVolume: 0.1,
        dubbedAudioVolume: 1.0,
      });
      if (res.data.success) {
        toast.info('FFmpeg video rendering started');
      }
    } catch (err: any) {
      setProcessing(false);
      toast.error(err.response?.data?.error || 'Failed to start video export');
    }
  };

  const steps = [
    { number: 1, label: 'Video Upload', icon: Upload },
    { number: 2, label: 'Transcribe Speech', icon: Mic },
    { number: 3, label: 'Translate Subtitles', icon: Languages },
    { number: 4, label: 'Generate AI Voice', icon: AudioWaveform },
    { number: 5, label: 'Render & Export', icon: Download },
  ];

  if (!currentProject) {
    return (
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-12 text-center max-w-xl mx-auto my-12 shadow-xl">
        <FileVideo className="w-12 h-12 text-[#2585F5] mx-auto mb-3" />
        <h2 className="text-xl font-bold text-white">No Project Selected</h2>
        <p className="text-xs text-slate-400 mt-2">
          Select an existing project or create a new one to launch the Video Translator studio.
        </p>
        <button
          onClick={() => (window.location.href = '/projects')}
          className="mt-6 px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110"
        >
          Go to My Projects
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Studio Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E3250]">
        <div>
          <div className="text-xs font-bold text-[#36B8F5] uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" /> End-to-End Dubbing Studio
          </div>
          <h1 className="text-2xl font-black text-white mt-1">{currentProject.title}</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs px-3 py-1 rounded-full bg-[#132238] border border-[#1E3250] text-slate-300 font-mono">
            {currentProject.sourceLanguage.toUpperCase()} → {currentProject.targetLanguage.toUpperCase()}
          </span>
        </div>
      </div>

      {/* Stepper Navigation */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {steps.map((s) => {
          const Icon = s.icon;
          const isActive = step === s.number;
          const isDone = (projectData?.project?.currentStep || 1) > s.number;

          return (
            <button
              key={s.number}
              onClick={() => setStep(s.number)}
              className={`p-3.5 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                isActive
                  ? 'bg-[#1E3250] border-[#2585F5] shadow-lg shadow-[#2585F5]/20 text-white'
                  : isDone
                  ? 'bg-[#132238]/60 border-emerald-500/40 text-emerald-400'
                  : 'bg-[#132238]/40 border-[#1E3250] text-slate-400 hover:border-slate-600'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                  isActive
                    ? 'bg-[#2585F5] text-white'
                    : isDone
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'bg-[#0D1728] text-slate-400'
                }`}
              >
                {isDone ? <CheckCircle2 className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
              </div>
              <div className="min-w-0">
                <div className="text-[10px] font-bold text-slate-400 uppercase">Step {s.number}</div>
                <div className="text-xs font-semibold truncate">{s.label}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Real-time Progress Bar (when active job is running) */}
      {processing && (
        <div className="p-5 rounded-2xl bg-[#0D1728] border border-[#2585F5]/50 shadow-xl space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-white flex items-center gap-2">
              <Loader2 className="w-4 h-4 text-[#36B8F5] animate-spin" />
              {currentJob?.currentStep || 'Processing background job...'}
            </span>
            <span className="font-mono text-[#36B8F5] font-bold">{currentJob?.progress || 0}%</span>
          </div>
          <div className="w-full bg-[#132238] h-2.5 rounded-full overflow-hidden border border-[#1E3250]">
            <div
              className="bg-gradient-to-r from-[#2585F5] to-[#36B8F5] h-full transition-all duration-300"
              style={{ width: `${currentJob?.progress || 10}%` }}
            />
          </div>
        </div>
      )}

      {/* Step Panels */}
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-8 shadow-xl">
        {/* STEP 1: Video Upload */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white">Upload Source Video</h3>
              <p className="text-xs text-slate-400 mt-1">
                Supports MP4, MKV, MOV, WebM, AVI, and M4V. Auto-analyzes resolution, duration, and audio streams.
              </p>
            </div>

            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-[#1E3250] hover:border-[#2585F5] rounded-2xl p-12 text-center cursor-pointer transition-colors bg-[#0D1728]/50 group"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="video/mp4,video/mkv,video/quicktime,video/webm,video/x-msvideo"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />
              <Upload className="w-12 h-12 text-slate-400 group-hover:text-[#36B8F5] mx-auto mb-3 transition-colors" />
              <div className="text-sm font-semibold text-white">Click or Drag & Drop Video File</div>
              <div className="text-xs text-slate-400 mt-1">Up to 2GB per file</div>

              {uploading && (
                <div className="max-w-xs mx-auto mt-4 space-y-1">
                  <div className="text-xs text-[#36B8F5] font-medium">Uploading: {uploadProgress}%</div>
                  <div className="w-full bg-[#132238] h-2 rounded-full overflow-hidden">
                    <div className="bg-[#2585F5] h-full" style={{ width: `${uploadProgress}%` }} />
                  </div>
                </div>
              )}
            </div>

            {projectData?.video && (
              <div className="p-4 rounded-xl bg-[#0D1728] border border-[#1E3250] flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-20 h-14 rounded-lg bg-[#132238] border border-[#1E3250] overflow-hidden shrink-0 flex items-center justify-center">
                    {projectData.video.thumbnailPath ? (
                      <img src={projectData.video.thumbnailPath} alt="Thumbnail" className="w-full h-full object-cover" />
                    ) : (
                      <FileVideo className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-white">{projectData.video.originalName}</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {projectData.video.resolution.width}x{projectData.video.resolution.height} •{' '}
                      {Math.round(projectData.video.duration)}s • {(projectData.video.size / (1024 * 1024)).toFixed(1)} MB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setStep(2)}
                  className="px-5 py-2 rounded-xl bg-[#2585F5] text-white text-xs font-semibold hover:brightness-110"
                >
                  Proceed to Speech-to-Text →
                </button>
              </div>
            )}
          </div>
        )}

        {/* STEP 2: Speech-to-Text */}
        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white">Transcribe Speech to Subtitles</h3>
              <p className="text-xs text-slate-400 mt-1">
                Faster-Whisper extracts dialogue timestamps and recognizes audio in Khmer, English, Thai, and 90+ languages.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Whisper Model Size
                </label>
                <select
                  value={whisperModel}
                  onChange={(e) => setWhisperModel(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
                >
                  <option value="base">Base (Fast, Low Memory)</option>
                  <option value="small">Small (Balanced)</option>
                  <option value="medium">Medium (High Precision)</option>
                  <option value="large-v3">Large-v3 (Maximum Accuracy)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Audio Speech Language
                </label>
                <select
                  value={transcriptionLang}
                  onChange={(e) => setTranscriptionLang(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
                >
                  <option value="auto">Automatic Detection</option>
                  <option value="km">Khmer (km)</option>
                  <option value="en">English (en)</option>
                  <option value="th">Thai (th)</option>
                  <option value="vi">Vietnamese (vi)</option>
                  <option value="zh">Chinese (zh)</option>
                  <option value="ja">Japanese (ja)</option>
                  <option value="fr">French (fr)</option>
                  <option value="es">Spanish (es)</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleStartTranscription}
                disabled={processing}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-2 disabled:opacity-50"
              >
                {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mic className="w-4 h-4" />}
                Start Speech Transcription
              </button>

              {projectData?.originalSubtitle && (
                <button
                  onClick={() => setStep(3)}
                  className="px-5 py-3 rounded-xl bg-[#1E3250] text-white text-xs font-semibold hover:bg-[#2585F5] transition-colors"
                >
                  Next: Translation →
                </button>
              )}
            </div>

            {/* Display Segments Preview */}
            {projectData?.originalSubtitle && (
              <div className="mt-4 p-4 rounded-xl bg-[#0D1728] border border-[#1E3250] max-h-60 overflow-y-auto space-y-2">
                <div className="text-xs font-bold text-slate-400 mb-2">
                  Recognized Subtitles ({projectData.originalSubtitle.segments.length} segments):
                </div>
                {projectData.originalSubtitle.segments.map((seg: any) => (
                  <div key={seg.id} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="font-mono text-[#36B8F5] shrink-0">
                      [{seg.start.toFixed(1)}s - {seg.end.toFixed(1)}s]
                    </span>
                    <span>{seg.text}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* STEP 3: Translation */}
        {step === 3 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white">Translate Subtitles with AI</h3>
              <p className="text-xs text-slate-400 mt-1">
                Context-aware translation preserving sentence duration and timestamp markers.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Target Language
                </label>
                <select
                  value={targetLang}
                  onChange={(e) => setTargetLang(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
                >
                  <option value="km">Khmer (km)</option>
                  <option value="en">English (en)</option>
                  <option value="th">Thai (th)</option>
                  <option value="vi">Vietnamese (vi)</option>
                  <option value="zh">Chinese (zh)</option>
                  <option value="ja">Japanese (ja)</option>
                  <option value="fr">French (fr)</option>
                  <option value="es">Spanish (es)</option>
                  <option value="de">German (de)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                  AI Translation Model
                </label>
                <select
                  value={translationProvider}
                  onChange={(e) => setTranslationProvider(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
                >
                  <option value="gemini">Google Gemini 1.5 Flash</option>
                  <option value="openai">OpenAI GPT-4o-mini</option>
                  <option value="local">Local Translation Adapter</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Style
                </label>
                <select
                  value={translationStyle}
                  onChange={(e) => setTranslationStyle(e.target.value as any)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
                >
                  <option value="formal">Formal & Professional</option>
                  <option value="casual">Casual & Conversational</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleStartTranslation}
                disabled={processing}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-2 disabled:opacity-50"
              >
                {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Languages className="w-4 h-4" />}
                Translate All Subtitle Segments
              </button>

              {projectData?.translatedSubtitle && (
                <button
                  onClick={() => setStep(4)}
                  className="px-5 py-3 rounded-xl bg-[#1E3250] text-white text-xs font-semibold hover:bg-[#2585F5] transition-colors"
                >
                  Next: AI Dubbing →
                </button>
              )}
            </div>

            {/* Display Translated Subtitles */}
            {projectData?.translatedSubtitle && (
              <div className="mt-4 p-4 rounded-xl bg-[#0D1728] border border-[#1E3250] max-h-60 overflow-y-auto space-y-2">
                <div className="text-xs font-bold text-slate-400 mb-2">
                  Translated Subtitles ({projectData.translatedSubtitle.segments.length} segments):
                </div>
                {projectData.translatedSubtitle.segments.map((seg: any) => (
                  <div key={seg.id} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="font-mono text-emerald-400 shrink-0">
                      [{seg.start.toFixed(1)}s - {seg.end.toFixed(1)}s]
                    </span>
                    <span>{seg.text}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* STEP 4: AI Voice Dubbing */}
        {step === 4 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white">Generate Multilingual AI Voice Dubbing</h3>
              <p className="text-xs text-slate-400 mt-1">
                Converts translated subtitles into time-aligned speech using Edge TTS neural voices or ElevenLabs.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Voice Gender
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setVoiceGender('female');
                      setSelectedVoice(targetLang === 'km' ? 'km-KH-SreymomNeural' : 'en-US-JennyNeural');
                    }}
                    className={`py-2 rounded-xl text-xs font-semibold border ${
                      voiceGender === 'female' ? 'bg-[#2585F5] border-[#2585F5] text-white' : 'bg-[#080F1D] border-[#1E3250] text-slate-400'
                    }`}
                  >
                    Female
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setVoiceGender('male');
                      setSelectedVoice(targetLang === 'km' ? 'km-KH-PisethNeural' : 'en-US-ChristopherNeural');
                    }}
                    className={`py-2 rounded-xl text-xs font-semibold border ${
                      voiceGender === 'male' ? 'bg-[#2585F5] border-[#2585F5] text-white' : 'bg-[#080F1D] border-[#1E3250] text-slate-400'
                    }`}
                  >
                    Male
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Neural Voice Engine
                </label>
                <select
                  value={selectedVoice}
                  onChange={(e) => setSelectedVoice(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
                >
                  <optgroup label="Khmer (Cambodia)">
                    <option value="km-KH-SreymomNeural">Sreymom (Female)</option>
                    <option value="km-KH-PisethNeural">Piseth (Male)</option>
                  </optgroup>
                  <optgroup label="English (US)">
                    <option value="en-US-JennyNeural">Jenny (Female)</option>
                    <option value="en-US-ChristopherNeural">Christopher (Male)</option>
                  </optgroup>
                  <optgroup label="Thai">
                    <option value="th-TH-PremwadeeNeural">Premwadee (Female)</option>
                    <option value="th-TH-NiwatNeural">Niwat (Male)</option>
                  </optgroup>
                  <optgroup label="Vietnamese">
                    <option value="vi-VN-HoaiMyNeural">Hoai My (Female)</option>
                    <option value="vi-VN-NamMinhNeural">Nam Minh (Male)</option>
                  </optgroup>
                  <optgroup label="Chinese">
                    <option value="zh-CN-XiaoxiaoNeural">Xiaoxiao (Female)</option>
                    <option value="zh-CN-YunxiNeural">Yunxi (Male)</option>
                  </optgroup>
                  <optgroup label="Japanese">
                    <option value="ja-JP-NanamiNeural">Nanami (Female)</option>
                    <option value="ja-JP-KeitaNeural">Keita (Male)</option>
                  </optgroup>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleStartDubbing}
                disabled={processing}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-2 disabled:opacity-50"
              >
                {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <AudioWaveform className="w-4 h-4" />}
                Synthesize Synchronized Voice Track
              </button>

              {projectData?.project?.generatedAudioFile && (
                <button
                  onClick={() => setStep(5)}
                  className="px-5 py-3 rounded-xl bg-[#1E3250] text-white text-xs font-semibold hover:bg-[#2585F5] transition-colors"
                >
                  Next: Export Video →
                </button>
              )}
            </div>

            {projectData?.project?.generatedAudioFile && (
              <div className="p-4 rounded-xl bg-[#0D1728] border border-[#1E3250] flex items-center gap-3">
                <Volume2 className="w-5 h-5 text-[#36B8F5]" />
                <div className="flex-1">
                  <div className="text-xs font-semibold text-white">Synchronized Dubbed Track Ready</div>
                  <audio controls src={projectData.project.generatedAudioFile} className="w-full mt-2 h-8" />
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP 5: Render & Video Export */}
        {step === 5 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white">Render & Export Dubbed Video</h3>
              <p className="text-xs text-slate-400 mt-1">
                FFmpeg burns subtitles and mixes the new AI speech with optional audio ducking.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Output Format
                </label>
                <select
                  value={exportFormat}
                  onChange={(e) => setExportFormat(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
                >
                  <option value="mp4">MP4 (H.264 / AAC - Universal)</option>
                  <option value="mkv">MKV (Matroska)</option>
                  <option value="mov">MOV (Apple QuickTime)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Resolution Preset
                </label>
                <select
                  value={exportResolution}
                  onChange={(e) => setExportResolution(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
                >
                  <option value="original">Original Resolution</option>
                  <option value="1080p">1080p Full HD</option>
                  <option value="720p">720p HD</option>
                </select>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 p-4 rounded-xl bg-[#0D1728] border border-[#1E3250]">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-white">
                <input
                  type="checkbox"
                  checked={burnSubtitles}
                  onChange={(e) => setBurnSubtitles(e.target.checked)}
                  className="w-4 h-4 rounded text-[#2585F5]"
                />
                Hardcode / Burn Translated Subtitles into Video
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-white">
                <input
                  type="checkbox"
                  checked={replaceAudio}
                  onChange={(e) => setReplaceAudio(e.target.checked)}
                  className="w-4 h-4 rounded text-[#2585F5]"
                />
                Mix Dubbed AI Voice (Ducks original speech)
              </label>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleStartExport}
                disabled={processing}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-2 disabled:opacity-50"
              >
                {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                Render Final Video via FFmpeg
              </button>

              {projectData?.project?.exportedVideoFile && (
                <a
                  href={projectData.project.exportedVideoFile}
                  download
                  className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold flex items-center gap-2 shadow"
                >
                  <Download className="w-4 h-4" /> Download Finished Video
                </a>
              )}
            </div>

            {projectData?.project?.exportedVideoFile && (
              <div className="p-4 rounded-xl bg-[#0D1728] border border-emerald-500/40 space-y-3">
                <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Export Complete
                </div>
                <video
                  controls
                  src={projectData.project.exportedVideoFile}
                  className="w-full rounded-xl border border-[#1E3250] max-h-96 bg-black"
                />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
