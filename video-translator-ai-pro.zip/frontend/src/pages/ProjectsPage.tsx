import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import { Project } from '../types';
import { useProjectStore } from '../stores/projectStore';
import { toast } from '../stores/toastStore';
import { Modal } from '../components/common/Modal';
import {
  FolderKanban,
  Plus,
  Search,
  Play,
  Trash2,
  Calendar,
  Clock,
  ArrowRight,
  Loader2,
  Filter,
} from 'lucide-react';

export const ProjectsPage: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [sourceLang, setSourceLang] = useState('auto');
  const [targetLang, setTargetLang] = useState('en');
  const [creating, setCreating] = useState(false);

  const { setCurrentProject } = useProjectStore();
  const navigate = useNavigate();

  const fetchProjects = async () => {
    try {
      const res = await api.get('/projects');
      if (res.data.success) {
        setProjects(res.data.projects);
      }
    } catch (err: any) {
      toast.error('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    setCreating(true);
    try {
      const res = await api.post('/projects', {
        title: newTitle.trim(),
        description: newDesc.trim(),
        sourceLanguage: sourceLang,
        targetLanguage: targetLang,
      });

      if (res.data.success) {
        toast.success('Project created!');
        setIsModalOpen(false);
        setNewTitle('');
        setNewDesc('');
        setCurrentProject(res.data.project);
        navigate('/translator');
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to create project');
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this project and all its media assets?')) return;

    try {
      const res = await api.delete(`/projects/${id}`);
      if (res.data.success) {
        toast.success('Project deleted');
        setProjects(projects.filter((p) => p._id !== id));
      }
    } catch (err: any) {
      toast.error('Failed to delete project');
    }
  };

  const handleSelect = (project: Project) => {
    setCurrentProject(project);
    navigate('/translator');
  };

  const filtered = projects.filter((p) =>
    p.title.toLowerCase().includes(search.toLowerCase()) ||
    p.targetLanguage.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <FolderKanban className="w-6 h-6 text-[#2585F5]" /> My Projects
          </h1>
          <p className="text-xs text-slate-400 mt-1">Manage video translation, dubbing, and subtitle files</p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow-lg shadow-[#2585F5]/25 hover:brightness-110 flex items-center gap-2 self-start sm:self-auto transition-all"
        >
          <Plus className="w-4 h-4" /> New Project
        </button>
      </div>

      {/* Filter and Search */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search projects by title or language..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-[#132238] border border-[#1E3250] text-xs text-white placeholder:text-slate-400 focus:outline-none focus:border-[#2585F5] transition-colors"
          />
        </div>
      </div>

      {/* Projects Grid */}
      {loading ? (
        <div className="flex justify-center p-12">
          <Loader2 className="w-8 h-8 text-[#2585F5] animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-[#132238] border border-dashed border-[#1E3250] rounded-2xl p-12 text-center">
          <FolderKanban className="w-12 h-12 text-slate-400 mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-white">No projects found</h3>
          <p className="text-xs text-slate-400 mt-1">Get started by creating your first dubbing project</p>
          <button
            onClick={() => setIsModalOpen(true)}
            className="mt-4 px-4 py-2 rounded-xl bg-[#2585F5] text-white text-xs font-semibold shadow"
          >
            Create New Project
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((project) => (
            <div
              key={project._id}
              onClick={() => handleSelect(project)}
              className="bg-[#132238] border border-[#1E3250] hover:border-[#2585F5]/60 rounded-2xl overflow-hidden shadow-lg hover:shadow-[#2585F5]/10 cursor-pointer transition-all duration-300 flex flex-col group"
            >
              {/* Thumbnail Container */}
              <div className="h-44 bg-[#0D1728] relative overflow-hidden flex items-center justify-center border-b border-[#1E3250]">
                {project.thumbnail ? (
                  <img
                    src={project.thumbnail}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                ) : (
                  <Play className="w-8 h-8 text-slate-400 group-hover:text-[#36B8F5] transition-colors" />
                )}
                <div className="absolute top-3 left-3 px-2 py-1 rounded-md bg-[#080F1D]/80 backdrop-blur-sm border border-[#1E3250] text-[10px] font-bold text-[#36B8F5] uppercase">
                  {project.sourceLanguage} → {project.targetLanguage}
                </div>
                <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded bg-black/70 backdrop-blur-sm text-[11px] font-mono text-white flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  {project.videoDuration ? `${Math.round(project.videoDuration)}s` : '0s'}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-white text-sm group-hover:text-[#36B8F5] transition-colors truncate">
                    {project.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {project.description || 'No description provided'}
                  </p>
                </div>

                <div className="mt-4 pt-4 border-t border-[#1E3250] flex items-center justify-between">
                  <span className="text-[11px] font-semibold uppercase px-2 py-0.5 rounded bg-[#0D1728] border border-[#1E3250] text-slate-300">
                    {project.status}
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => handleDelete(project._id, e)}
                      title="Delete Project"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-[#1E3250] transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <button className="p-1.5 rounded-lg text-slate-400 group-hover:text-white group-hover:bg-[#2585F5] transition-all">
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Project Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Create New Translation Project">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
              Project Title *
            </label>
            <input
              type="text"
              required
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="e.g., Tech Product Keynote Khmer Dub"
              className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-sm text-white focus:outline-none focus:border-[#2585F5]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
              Description (Optional)
            </label>
            <textarea
              rows={2}
              value={newDesc}
              onChange={(e) => setNewDesc(e.target.value)}
              placeholder="Brief details or notes..."
              className="w-full px-4 py-2 rounded-xl bg-[#080F1D] border border-[#1E3250] text-sm text-white focus:outline-none focus:border-[#2585F5]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                Source Speech Language
              </label>
              <select
                value={sourceLang}
                onChange={(e) => setSourceLang(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white focus:outline-none focus:border-[#2585F5]"
              >
                <option value="auto">Auto Detect Language</option>
                <option value="en">English (en)</option>
                <option value="km">Khmer (km)</option>
                <option value="th">Thai (th)</option>
                <option value="vi">Vietnamese (vi)</option>
                <option value="zh">Chinese (zh)</option>
                <option value="ja">Japanese (ja)</option>
                <option value="fr">French (fr)</option>
                <option value="es">Spanish (es)</option>
                <option value="de">German (de)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                Target Dubbing Language
              </label>
              <select
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white focus:outline-none focus:border-[#2585F5]"
              >
                <option value="km">Khmer (km)</option>
                <option value="en">English (en)</option>
                <option value="th">Thai (th)</option>
                <option value="vi">Vietnamese (vi)</option>
                <option value="zh">Chinese (zh)</option>
                <option value="ja">Japanese (ja)</option>
                <option value="fr">French (fr)</option>
                <option value="es">Spanish (es)</option>
                <option value="de">German (de)</option>
              </select>
            </div>
          </div>

          <div className="pt-4 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={creating}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-2"
            >
              {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create & Open Studio'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
