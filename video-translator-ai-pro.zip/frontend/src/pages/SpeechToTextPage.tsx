import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useProjectStore } from '../stores/projectStore';
import { toast } from '../stores/toastStore';
import { Mic, Download, Play, RefreshCw, FileText, CheckCircle2, Loader2 } from 'lucide-react';

export const SpeechToTextPage: React.FC = () => {
  const { currentProject } = useProjectStore();
  const [subtitle, setSubtitle] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [language, setLanguage] = useState('auto');
  const [model, setModel] = useState('base');

  const fetchSubtitles = async () => {
    if (!currentProject) return;
    setLoading(true);
    try {
      const res = await api.get(`/subtitles?projectId=${currentProject._id}&type=original`);
      if (res.data.success) {
        setSubtitle(res.data.subtitle);
      }
    } catch {
      // none yet
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubtitles();
  }, [currentProject]);

  const handleTranscribe = async () => {
    if (!currentProject) {
      toast.error('Select a project first');
      return;
    }
    setTranscribing(true);
    try {
      const res = await api.post('/transcription/start', {
        projectId: currentProject._id,
        language,
        model,
        provider: 'whisper',
      });
      if (res.data.success) {
        toast.success('Transcription job started');
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Transcription failed to start');
    } finally {
      setTranscribing(false);
    }
  };

  const handleExport = (format: 'srt' | 'vtt' | 'txt') => {
    if (!currentProject) return;
    window.open(`/api/transcription/export?projectId=${currentProject._id}&format=${format}&type=original`, '_blank');
  };

  if (!currentProject) {
    return (
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-12 text-center max-w-xl mx-auto my-12">
        <Mic className="w-12 h-12 text-[#2585F5] mx-auto mb-3" />
        <h2 className="text-xl font-bold text-white">No Project Selected</h2>
        <p className="text-xs text-slate-400 mt-2">Please select an existing project with an uploaded video.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E3250]">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Mic className="w-6 h-6 text-[#2585F5]" /> Speech to Text Studio
          </h1>
          <p className="text-xs text-slate-400 mt-1">Faster-Whisper offline & cloud speech recognition</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleExport('srt')}
            disabled={!subtitle}
            className="px-3.5 py-2 rounded-xl bg-[#1E3250] hover:bg-[#2585F5] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-40"
          >
            <Download className="w-3.5 h-3.5" /> Export SRT
          </button>
          <button
            onClick={() => handleExport('vtt')}
            disabled={!subtitle}
            className="px-3.5 py-2 rounded-xl bg-[#1E3250] hover:bg-[#2585F5] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-40"
          >
            <Download className="w-3.5 h-3.5" /> Export VTT
          </button>
          <button
            onClick={() => handleExport('txt')}
            disabled={!subtitle}
            className="px-3.5 py-2 rounded-xl bg-[#1E3250] hover:bg-[#2585F5] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-40"
          >
            <FileText className="w-3.5 h-3.5" /> Export TXT
          </button>
        </div>
      </div>

      {/* Control Card */}
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Language</label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
            >
              <option value="auto">Automatic Detection</option>
              <option value="km">Khmer (km)</option>
              <option value="en">English (en)</option>
              <option value="th">Thai (th)</option>
              <option value="vi">Vietnamese (vi)</option>
              <option value="zh">Chinese (zh)</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Model</label>
            <select
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
            >
              <option value="tiny">Tiny (Ultra Fast)</option>
              <option value="base">Base (Recommended)</option>
              <option value="small">Small (High Accuracy)</option>
              <option value="medium">Medium (Pro)</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleTranscribe}
          disabled={transcribing}
          className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-2"
        >
          {transcribing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mic className="w-4 h-4" />}
          Run Transcription
        </button>
      </div>

      {/* Segments Table */}
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-white">Original Subtitle Segments</h3>
          <span className="text-xs text-slate-400 font-mono">
            {subtitle ? `${subtitle.segments.length} segments` : 'No subtitles yet'}
          </span>
        </div>

        {subtitle && subtitle.segments.length > 0 ? (
          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
            {subtitle.segments.map((seg: any) => (
              <div
                key={seg.id}
                className="p-3 rounded-xl bg-[#0D1728] border border-[#1E3250] flex items-start gap-4 hover:border-[#2585F5]/40 transition-colors"
              >
                <div className="text-xs font-bold text-slate-400 font-mono w-8">#{seg.id}</div>
                <div className="text-xs font-mono text-[#36B8F5] shrink-0">
                  {seg.start.toFixed(2)}s → {seg.end.toFixed(2)}s
                </div>
                <div className="text-xs text-white flex-1 leading-relaxed">{seg.text}</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-12 text-center text-xs text-slate-400">
            No speech transcripts generated yet. Click "Run Transcription" to generate.
          </div>
        )}
      </div>
    </div>
  );
};
