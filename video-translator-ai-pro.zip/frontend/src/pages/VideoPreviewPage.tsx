import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useProjectStore } from '../stores/projectStore';
import { PlaySquare, Subtitles, Volume2, CheckCircle2 } from 'lucide-react';

export const VideoPreviewPage: React.FC = () => {
  const { currentProject } = useProjectStore();
  const [projectData, setProjectData] = useState<any>(null);
  const [subtitleMode, setSubtitleMode] = useState<'translated' | 'original' | 'off'>('translated');
  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    if (!currentProject) return;
    const fetchProject = async () => {
      try {
        const res = await api.get(`/projects/${currentProject._id}`);
        if (res.data.success) {
          setProjectData(res.data);
        }
      } catch {}
    };
    fetchProject();
  }, [currentProject]);

  if (!currentProject) {
    return (
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-12 text-center max-w-xl mx-auto my-12">
        <PlaySquare className="w-12 h-12 text-[#2585F5] mx-auto mb-3" />
        <h2 className="text-xl font-bold text-white">No Project Selected</h2>
        <p className="text-xs text-slate-400 mt-2">Select a project to preview video with subtitles.</p>
      </div>
    );
  }

  const activeSubtitles =
    subtitleMode === 'translated'
      ? projectData?.translatedSubtitle?.segments || []
      : subtitleMode === 'original'
      ? projectData?.originalSubtitle?.segments || []
      : [];

  const currentSegment = activeSubtitles.find(
    (s: any) => currentTime >= s.start && currentTime <= s.end
  );

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <PlaySquare className="w-6 h-6 text-[#2585F5]" /> Video Studio Preview
        </h1>
        <p className="text-xs text-slate-400 mt-1">Live subtitle overlay & dual audio playback preview</p>
      </div>

      {/* Video Container */}
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl overflow-hidden shadow-2xl p-4 space-y-4">
        <div className="relative aspect-video bg-black rounded-xl overflow-hidden flex items-center justify-center">
          {projectData?.project?.videoFile ? (
            <video
              controls
              src={projectData.project.videoFile}
              onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
              className="w-full h-full object-contain"
            />
          ) : (
            <div className="text-xs text-slate-400">No video uploaded yet</div>
          )}

          {/* Subtitle Overlay */}
          {currentSegment && (
            <div className="absolute bottom-14 left-1/2 -translate-x-1/2 max-w-[85%] text-center px-4 py-2 rounded-xl bg-black/80 backdrop-blur-sm border border-white/10 text-white text-sm font-semibold pointer-events-none shadow-2xl">
              {currentSegment.text}
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-[#0D1728] border border-[#1E3250]">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Subtitles className="w-4 h-4 text-[#36B8F5]" /> Subtitle Track:
            </span>
            <div className="flex items-center bg-[#132238] p-1 rounded-lg border border-[#1E3250]">
              {(['translated', 'original', 'off'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setSubtitleMode(mode)}
                  className={`px-3 py-1 rounded-md text-xs font-semibold capitalize ${
                    subtitleMode === mode ? 'bg-[#2585F5] text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          <div className="text-xs font-mono text-slate-400">
            Time: <span className="text-[#36B8F5] font-bold">{currentTime.toFixed(1)}s</span>
          </div>
        </div>
      </div>
    </div>
  );
};
