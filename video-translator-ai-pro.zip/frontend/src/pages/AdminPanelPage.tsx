import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { toast } from '../stores/toastStore';
import { ShieldCheck, Users, Activity, HardDrive, Settings, Loader2 } from 'lucide-react';

export const AdminPanelPage: React.FC = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [jobs, setJobs] = useState<any[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchAdminData = async () => {
    try {
      const [usersRes, jobsRes, metricsRes] = await Promise.all([
        api.get('/admin/users'),
        api.get('/admin/jobs'),
        api.get('/admin/metrics'),
      ]);
      if (usersRes.data.success) setUsers(usersRes.data.users);
      if (jobsRes.data.success) setJobs(jobsRes.data.jobs);
      if (metricsRes.data.success) setMetrics(metricsRes.data.metrics);
    } catch {
      toast.error('Failed to load admin panel data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleRoleChange = async (userId: string, newRole: string) => {
    try {
      const res = await api.put(`/admin/users/${userId}/role`, { role: newRole });
      if (res.data.success) {
        toast.success('User role updated');
        setUsers(users.map((u) => (u._id === userId ? { ...u, role: newRole } : u)));
      }
    } catch (err: any) {
      toast.error('Failed to update role');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <ShieldCheck className="w-6 h-6 text-[#2585F5]" /> Enterprise Admin Panel
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Manage system users, background jobs, storage utilization, and global settings
        </p>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 uppercase">Total Registered Users</div>
          <div className="text-2xl font-black text-white mt-2">{metrics?.totalUsers || 0}</div>
        </div>
        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 uppercase">Total Projects Created</div>
          <div className="text-2xl font-black text-white mt-2">{metrics?.totalProjects || 0}</div>
        </div>
        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 uppercase">Active Processing Jobs</div>
          <div className="text-2xl font-black text-white mt-2">{metrics?.activeJobsCount || 0}</div>
        </div>
        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 uppercase">Disk Storage Used</div>
          <div className="text-2xl font-black text-white mt-2">
            {metrics?.storageStats ? (metrics.storageStats.totalSizeBytes / (1024 * 1024)).toFixed(1) : 0} MB
          </div>
        </div>
      </div>

      {/* Users Management */}
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl">
        <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
          <Users className="w-4 h-4 text-[#36B8F5]" /> User Account Management
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0D1728] text-slate-400 uppercase font-semibold border-b border-[#1E3250]">
              <tr>
                <th className="py-3 px-4">Name</th>
                <th className="py-3 px-4">Email</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E3250]">
              {users.map((u) => (
                <tr key={u._id} className="hover:bg-[#0D1728]/40">
                  <td className="py-3 px-4 font-semibold text-white">{u.name}</td>
                  <td className="py-3 px-4 text-slate-400">{u.email}</td>
                  <td className="py-3 px-4">
                    <span className="font-mono text-xs uppercase px-2 py-0.5 rounded bg-[#0D1728] border border-[#1E3250] text-[#36B8F5]">
                      {u.role}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-emerald-400 font-bold uppercase text-[10px]">
                    {u.isActive ? 'Active' : 'Suspended'}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <select
                      value={u.role}
                      onChange={(e) => handleRoleChange(u._id, e.target.value)}
                      className="px-2 py-1 rounded bg-[#080F1D] border border-[#1E3250] text-xs text-white"
                    >
                      <option value="user">User</option>
                      <option value="admin">Admin</option>
                      <option value="superadmin">Super Admin</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
