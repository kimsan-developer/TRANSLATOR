import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import { useProjectStore } from '../stores/projectStore';
import {
  FolderKanban,
  Video,
  Languages,
  AudioWaveform,
  HardDrive,
  Cpu,
  ArrowRight,
  Clock,
  Play,
  Wand2,
  AlertCircle,
  CheckCircle2,
  Loader2,
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const { setCurrentProject } = useProjectStore();
  const navigate = useNavigate();

  const fetchStats = async () => {
    try {
      const res = await api.get('/projects/dashboard/stats');
      if (res.data.success) {
        setData(res.data);
      }
    } catch (err) {
      console.error('Failed to load dashboard statistics', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 5000); // Polling update
    return () => clearInterval(interval);
  }, []);

  const handleOpenProject = (project: any) => {
    setCurrentProject(project);
    navigate('/translator');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 text-[#2585F5] animate-spin" />
      </div>
    );
  }

  const stats = data?.stats || {};
  const recentProjects = data?.recentProjects || [];
  const activeJobs = data?.activeJobs || [];
  const providers = data?.providers || [];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#132238] via-[#0E1A2C] to-[#132238] border border-[#1E3250] p-8 shadow-xl">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#2585F5]/10 border border-[#2585F5]/30 text-[#36B8F5] text-xs font-semibold mb-3">
            <span className="w-2 h-2 rounded-full bg-[#36B8F5] animate-ping" />
            AI Video Dubbing Studio Pro
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Transcribe, Translate, and Voice Your Videos in Minutes
          </h1>
          <p className="text-slate-300 text-sm mt-2 leading-relaxed">
            High-precision Faster-Whisper speech recognition, neural context translation, and multilingual AI voice synthesis with zero latency.
          </p>
          <div className="flex flex-wrap items-center gap-3 mt-6">
            <Link
              to="/translator"
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-sm font-semibold shadow-lg shadow-[#2585F5]/30 hover:brightness-110 flex items-center gap-2 transition-all"
            >
              <Wand2 className="w-4 h-4" /> Start New Video Dubbing
            </Link>
            <Link
              to="/projects"
              className="px-5 py-2.5 rounded-xl bg-[#1E3250]/70 hover:bg-[#1E3250] text-slate-200 text-sm font-semibold border border-[#2585F5]/20 flex items-center gap-2 transition-all"
            >
              <FolderKanban className="w-4 h-4" /> Browse Projects
            </Link>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Projects</span>
            <div className="w-9 h-9 rounded-xl bg-[#2585F5]/15 text-[#36B8F5] flex items-center justify-center">
              <FolderKanban className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-3">{stats.totalProjects || 0}</div>
          <div className="text-xs text-slate-400 mt-1 flex items-center gap-1">
            <span className="text-emerald-400 font-medium">Active workspace</span>
          </div>
        </div>

        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Videos Processed</span>
            <div className="w-9 h-9 rounded-xl bg-sky-500/15 text-sky-400 flex items-center justify-center">
              <Video className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-3">{stats.totalVideosProcessed || 0}</div>
          <div className="text-xs text-slate-400 mt-1">Rendered with FFmpeg</div>
        </div>

        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Translations</span>
            <div className="w-9 h-9 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center">
              <Languages className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-3">{stats.totalTranslations || 0}</div>
          <div className="text-xs text-slate-400 mt-1">Multilingual subtitles</div>
        </div>

        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">AI Dubbed Audio</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <AudioWaveform className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-3">{stats.totalGeneratedAudio || 0}</div>
          <div className="text-xs text-slate-400 mt-1">Edge TTS & Neural Voices</div>
        </div>
      </div>

      {/* Active Processing Jobs (Real-time updates) */}
      {activeJobs.length > 0 && (
        <div className="bg-[#132238] border border-[#2585F5]/40 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Loader2 className="w-5 h-5 text-[#36B8F5] animate-spin" />
              Active Media Processing Jobs ({activeJobs.length})
            </h3>
            <span className="text-xs text-slate-400">Processing in background workers</span>
          </div>

          <div className="space-y-3">
            {activeJobs.map((job: any) => (
              <div
                key={job._id}
                className="p-4 rounded-xl bg-[#0D1728] border border-[#1E3250] flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-[#2585F5]/20 text-[#36B8F5] border border-[#2585F5]/30">
                      {job.type}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">Job #{job._id.slice(-6)}</span>
                  </div>
                  <div className="text-sm font-semibold text-white mt-1">{job.currentStep}</div>
                  {/* Progress bar */}
                  <div className="w-full bg-[#132238] h-2 rounded-full mt-2.5 overflow-hidden border border-[#1E3250]">
                    <div
                      className="bg-gradient-to-r from-[#2585F5] to-[#36B8F5] h-full transition-all duration-300"
                      style={{ width: `${job.progress}%` }}
                    />
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-sm font-bold text-[#36B8F5] font-mono">{job.progress}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Projects Table & AI Engine Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Projects */}
        <div className="lg:col-span-2 bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-white">Recent Projects</h3>
            <Link to="/projects" className="text-xs font-semibold text-[#36B8F5] hover:underline flex items-center gap-1">
              View All <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {recentProjects.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center border border-dashed border-[#1E3250] rounded-xl">
              <FolderKanban className="w-10 h-10 text-slate-400 mb-2" />
              <p className="text-sm font-medium text-slate-300">No projects yet</p>
              <p className="text-xs text-slate-400 mt-1">Start by creating your first video translation</p>
              <Link
                to="/translator"
                className="mt-4 px-4 py-2 rounded-xl bg-[#2585F5] text-white text-xs font-semibold shadow hover:brightness-110"
              >
                Create Project
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {recentProjects.map((p: any) => (
                <div
                  key={p._id}
                  onClick={() => handleOpenProject(p)}
                  className="p-3.5 rounded-xl bg-[#0D1728] border border-[#1E3250] hover:border-[#2585F5]/50 cursor-pointer transition-all flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-14 h-10 rounded-lg bg-[#132238] border border-[#1E3250] overflow-hidden shrink-0 flex items-center justify-center">
                      {p.thumbnail ? (
                        <img src={p.thumbnail} alt={p.title} className="w-full h-full object-cover" />
                      ) : (
                        <Play className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-sm font-semibold text-white truncate group-hover:text-[#36B8F5] transition-colors">
                        {p.title}
                      </h4>
                      <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-400">
                        <span>{p.sourceLanguage.toUpperCase()} → {p.targetLanguage.toUpperCase()}</span>
                        <span>•</span>
                        <span>{p.videoDuration ? `${Math.round(p.videoDuration)}s` : 'Pending'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs px-2.5 py-1 rounded-full bg-[#132238] border border-[#1E3250] text-slate-300 font-medium capitalize">
                      {p.status}
                    </span>
                    <button className="p-2 rounded-lg bg-[#1E3250] text-slate-300 group-hover:text-white group-hover:bg-[#2585F5] transition-all">
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* AI Providers Live Status */}
        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#36B8F5]" /> AI Providers
            </h3>
            <Link to="/providers" className="text-xs font-semibold text-[#36B8F5] hover:underline">
              Configure
            </Link>
          </div>

          <div className="space-y-3 flex-1">
            {providers.map((p: any) => (
              <div
                key={p.id || p.type}
                className="p-3 rounded-xl bg-[#0D1728] border border-[#1E3250] flex items-center justify-between"
              >
                <div>
                  <div className="text-xs font-semibold text-white">{p.name}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5 capitalize">{p.type}</div>
                </div>
                <div className="flex items-center gap-1.5 text-xs font-medium">
                  {p.status === 'online' ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Ready
                    </span>
                  ) : p.status === 'unconfigured' ? (
                    <span className="text-amber-400 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" /> No Key
                    </span>
                  ) : (
                    <span className="text-slate-400">Offline</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
