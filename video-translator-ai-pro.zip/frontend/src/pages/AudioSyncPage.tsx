import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useProjectStore } from '../stores/projectStore';
import { toast } from '../stores/toastStore';
import { Sliders, Volume2, Music, Mic, Play, Pause, RotateCcw } from 'lucide-react';

export const AudioSyncPage: React.FC = () => {
  const { currentProject } = useProjectStore();
  const [data, setData] = useState<any>(null);
  const [origVol, setOrigVol] = useState(10);
  const [dubVol, setDubVol] = useState(100);
  const [bgVol, setBgVol] = useState(15);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    if (!currentProject) return;
    const fetchTimeline = async () => {
      try {
        const res = await api.get(`/editor/${currentProject._id}/timeline`);
        if (res.data.success) {
          setData(res.data);
        }
      } catch {}
    };
    fetchTimeline();
  }, [currentProject]);

  if (!currentProject) {
    return (
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-12 text-center max-w-xl mx-auto my-12">
        <Sliders className="w-12 h-12 text-[#2585F5] mx-auto mb-3" />
        <h2 className="text-xl font-bold text-white">No Project Selected</h2>
        <p className="text-xs text-slate-400 mt-2">Select a project to balance audio tracks and synchronization.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E3250]">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Sliders className="w-6 h-6 text-[#2585F5]" /> Audio Synchronization & Mixing
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Fine-tune audio ducking, background music levels, and dubbed speech synchronization
          </p>
        </div>
      </div>

      {/* Video & Audio Timeline Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          {/* Video Box */}
          <div className="bg-black rounded-2xl border border-[#1E3250] overflow-hidden aspect-video flex items-center justify-center relative">
            {data?.project?.videoFile ? (
              <video
                controls
                src={data.project.videoFile}
                className="w-full h-full object-contain"
              />
            ) : (
              <div className="text-xs text-slate-400">No video loaded</div>
            )}
          </div>

          {/* Waveform Track Simulator */}
          <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
              <span className="flex items-center gap-2">
                <Mic className="w-4 h-4 text-[#36B8F5]" /> Dubbed Speech Track
              </span>
              <span className="font-mono text-[#36B8F5]">{dubVol}%</span>
            </div>
            <div className="h-10 bg-[#080F1D] rounded-xl border border-[#1E3250] flex items-center px-4 overflow-hidden">
              <div className="w-full h-6 flex items-center gap-1">
                {Array.from({ length: 40 }).map((_, i) => (
                  <div
                    key={i}
                    className="flex-1 bg-gradient-to-t from-[#2585F5] to-[#36B8F5] rounded-full"
                    style={{ height: `${Math.max(15, (Math.sin(i * 0.5) + 1) * 45)}%` }}
                  />
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
              <span className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-slate-400" /> Original Video Audio (Ducked)
              </span>
              <span className="font-mono text-slate-400">{origVol}%</span>
            </div>
            <div className="h-8 bg-[#080F1D] rounded-xl border border-[#1E3250] flex items-center px-4 overflow-hidden opacity-50">
              <div className="w-full h-4 flex items-center gap-1">
                {Array.from({ length: 40 }).map((_, i) => (
                  <div
                    key={i}
                    className="flex-1 bg-slate-500 rounded-full"
                    style={{ height: `${Math.max(10, (Math.cos(i * 0.4) + 1) * 35)}%` }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Mixer Sliders Card */}
        <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl space-y-6">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Audio Mixer Controls</h3>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-2">
                <span>Dubbed AI Voice Volume</span>
                <span className="font-mono text-[#36B8F5]">{dubVol}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={dubVol}
                onChange={(e) => setDubVol(parseInt(e.target.value, 10))}
                className="w-full accent-[#2585F5]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-2">
                <span>Original Speech (Ducking)</span>
                <span className="font-mono text-slate-400">{origVol}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={origVol}
                onChange={(e) => setOrigVol(parseInt(e.target.value, 10))}
                className="w-full accent-[#2585F5]"
              />
              <p className="text-[11px] text-slate-400 mt-1">Recommended: 5% - 15% for background presence.</p>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-2">
                <span>Background Music Track</span>
                <span className="font-mono text-slate-400">{bgVol}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={bgVol}
                onChange={(e) => setBgVol(parseInt(e.target.value, 10))}
                className="w-full accent-[#2585F5]"
              />
            </div>
          </div>

          <button
            onClick={() => toast.success('Audio mixing parameters saved')}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110"
          >
            Apply Mixing Levels
          </button>
        </div>
      </div>
    </div>
  );
};
