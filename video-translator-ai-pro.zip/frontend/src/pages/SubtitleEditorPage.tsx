import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useProjectStore } from '../stores/projectStore';
import { toast } from '../stores/toastStore';
import {
  Subtitles,
  Save,
  Plus,
  Trash2,
  Scissors,
  Merge,
  Search,
  Upload,
  Download,
  Play,
  RotateCcw,
} from 'lucide-react';

export const SubtitleEditorPage: React.FC = () => {
  const { currentProject } = useProjectStore();
  const [subType, setSubType] = useState<'original' | 'translated'>('translated');
  const [segments, setSegments] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [replaceTerm, setReplaceTerm] = useState('');
  const [selectedSegId, setSelectedSegId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);

  const fetchSubtitles = async () => {
    if (!currentProject) return;
    try {
      const res = await api.get(`/subtitles?projectId=${currentProject._id}&type=${subType}`);
      if (res.data.success && res.data.subtitle) {
        setSegments(res.data.subtitle.segments || []);
      } else {
        setSegments([]);
      }
    } catch {
      setSegments([]);
    }
  };

  useEffect(() => {
    fetchSubtitles();
  }, [currentProject, subType]);

  const handleSave = async () => {
    if (!currentProject) return;
    setSaving(true);
    try {
      const res = await api.put('/subtitles/update', {
        projectId: currentProject._id,
        type: subType,
        segments,
      });
      if (res.data.success) {
        toast.success('Subtitles saved to database');
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to save subtitles');
    } finally {
      setSaving(false);
    }
  };

  const handleTextChange = (id: number, newText: string) => {
    setSegments(segments.map((s) => (s.id === id ? { ...s, text: newText } : s)));
  };

  const handleTimeChange = (id: number, field: 'start' | 'end', val: number) => {
    setSegments(segments.map((s) => (s.id === id ? { ...s, [field]: val } : s)));
  };

  const handleAddSegment = () => {
    const lastSeg = segments[segments.length - 1];
    const newStart = lastSeg ? lastSeg.end + 0.5 : 0;
    const newEnd = newStart + 3.0;
    const newId = segments.length > 0 ? Math.max(...segments.map((s) => s.id)) + 1 : 1;

    setSegments([...segments, { id: newId, start: newStart, end: newEnd, text: 'New subtitle text' }]);
  };

  const handleDeleteSegment = (id: number) => {
    setSegments(segments.filter((s) => s.id !== id).map((s, idx) => ({ ...s, id: idx + 1 })));
  };

  const handleSplit = async (id: number) => {
    const seg = segments.find((s) => s.id === id);
    if (!seg) return;
    const mid = (seg.start + seg.end) / 2;

    try {
      const res = await api.post('/subtitles/split', {
        projectId: currentProject?._id,
        type: subType,
        segmentId: id,
        splitTime: mid,
      });
      if (res.data.success) {
        setSegments(res.data.subtitle.segments);
        toast.success('Segment split into two');
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to split segment');
    }
  };

  const handleSearchReplace = () => {
    if (!searchTerm) return;
    let count = 0;
    const updated = segments.map((s) => {
      if (s.text.includes(searchTerm)) {
        count++;
        return { ...s, text: s.text.replaceAll(searchTerm, replaceTerm) };
      }
      return s;
    });
    setSegments(updated);
    toast.success(`Replaced in ${count} segment(s)`);
  };

  if (!currentProject) {
    return (
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-12 text-center max-w-xl mx-auto my-12">
        <Subtitles className="w-12 h-12 text-[#2585F5] mx-auto mb-3" />
        <h2 className="text-xl font-bold text-white">No Project Selected</h2>
        <p className="text-xs text-slate-400 mt-2">Select a project to open the interactive Subtitle Editor.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E3250]">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Subtitles className="w-6 h-6 text-[#2585F5]" /> Interactive Subtitle Editor
          </h1>
          <p className="text-xs text-slate-400 mt-1">Fine-tune timings, split, merge, and edit subtitles</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center bg-[#132238] p-1 rounded-xl border border-[#1E3250]">
            <button
              onClick={() => setSubType('translated')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                subType === 'translated' ? 'bg-[#2585F5] text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Translated Subtitles
            </button>
            <button
              onClick={() => setSubType('original')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                subType === 'original' ? 'bg-[#2585F5] text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Original Subtitles
            </button>
          </div>

          <button
            onClick={handleSave}
            disabled={saving}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow hover:brightness-110 flex items-center gap-1.5"
          >
            <Save className="w-4 h-4" /> Save Subtitles
          </button>
        </div>
      </div>

      {/* Search & Replace Bar */}
      <div className="flex flex-wrap items-center gap-3 bg-[#132238] border border-[#1E3250] rounded-2xl p-4 shadow-lg">
        <div className="flex-1 min-w-[200px]">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Find text..."
            className="w-full px-3 py-2 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
          />
        </div>
        <div className="flex-1 min-w-[200px]">
          <input
            type="text"
            value={replaceTerm}
            onChange={(e) => setReplaceTerm(e.target.value)}
            placeholder="Replace with..."
            className="w-full px-3 py-2 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
          />
        </div>
        <button
          onClick={handleSearchReplace}
          className="px-4 py-2 rounded-xl bg-[#1E3250] hover:bg-[#2585F5] text-white text-xs font-semibold"
        >
          Replace All
        </button>
        <button
          onClick={handleAddSegment}
          className="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30 text-xs font-semibold flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" /> Add Segment
        </button>
      </div>

      {/* Subtitles Table Editor */}
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0D1728] text-slate-400 uppercase font-semibold border-b border-[#1E3250]">
              <tr>
                <th className="py-3 px-4 w-12">#</th>
                <th className="py-3 px-4 w-28">Start (s)</th>
                <th className="py-3 px-4 w-28">End (s)</th>
                <th className="py-3 px-4">Subtitle Content</th>
                <th className="py-3 px-4 w-32 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E3250]">
              {segments.map((seg) => (
                <tr
                  key={seg.id}
                  className={`hover:bg-[#0D1728]/50 transition-colors ${
                    selectedSegId === seg.id ? 'bg-[#0D1728]' : ''
                  }`}
                  onClick={() => setSelectedSegId(seg.id)}
                >
                  <td className="py-3 px-4 font-mono font-bold text-slate-400">{seg.id}</td>
                  <td className="py-3 px-4">
                    <input
                      type="number"
                      step="0.1"
                      value={seg.start}
                      onChange={(e) => handleTimeChange(seg.id, 'start', parseFloat(e.target.value) || 0)}
                      className="w-20 px-2 py-1 rounded bg-[#080F1D] border border-[#1E3250] font-mono text-xs text-white"
                    />
                  </td>
                  <td className="py-3 px-4">
                    <input
                      type="number"
                      step="0.1"
                      value={seg.end}
                      onChange={(e) => handleTimeChange(seg.id, 'end', parseFloat(e.target.value) || 0)}
                      className="w-20 px-2 py-1 rounded bg-[#080F1D] border border-[#1E3250] font-mono text-xs text-white"
                    />
                  </td>
                  <td className="py-3 px-4">
                    <textarea
                      rows={1}
                      value={seg.text}
                      onChange={(e) => handleTextChange(seg.id, e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-[#080F1D] border border-[#1E3250] text-xs text-white focus:outline-none focus:border-[#2585F5]"
                    />
                  </td>
                  <td className="py-3 px-4 text-right space-x-1">
                    <button
                      onClick={() => handleSplit(seg.id)}
                      title="Split in half"
                      className="p-1.5 rounded hover:bg-[#1E3250] text-slate-400 hover:text-white"
                    >
                      <Scissors className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteSegment(seg.id)}
                      title="Delete segment"
                      className="p-1.5 rounded hover:bg-[#1E3250] text-slate-400 hover:text-rose-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
