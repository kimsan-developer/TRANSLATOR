import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { AIProvider } from '../types';
import { toast } from '../stores/toastStore';
import { Key, ShieldCheck, Lock, Save, Loader2 } from 'lucide-react';

export const ApiSettingsPage: React.FC = () => {
  const [providers, setProviders] = useState<AIProvider[]>([]);
  const [loading, setLoading] = useState(true);
  const [keys, setKeys] = useState<Record<string, string>>({});
  const [savingId, setSavingId] = useState<string | null>(null);

  const fetchProviders = async () => {
    try {
      const res = await api.get('/providers');
      if (res.data.success) {
        setProviders(res.data.providers);
      }
    } catch {
      toast.error('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProviders();
  }, []);

  const handleSaveKey = async (provider: AIProvider) => {
    const rawKey = keys[provider.id];
    if (!rawKey) return;

    setSavingId(provider.id);
    try {
      const res = await api.put(`/providers/${provider.id}`, { apiKey: rawKey });
      if (res.data.success) {
        toast.success(`${provider.name} API key encrypted and saved!`);
        setKeys((prev) => ({ ...prev, [provider.id]: '' }));
        fetchProviders();
      }
    } catch {
      toast.error('Failed to save API key');
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <Key className="w-6 h-6 text-[#2585F5]" /> API & Provider Settings
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Configure API credentials. All keys are encrypted at rest with AES-256 and never exposed to the frontend.
        </p>
      </div>

      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl space-y-6">
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-3">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <p className="text-xs text-emerald-200">
            Zero-Leak Encryption: Keys are processed exclusively on the server and masked before any client response.
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center p-8">
            <Loader2 className="w-6 h-6 text-[#2585F5] animate-spin" />
          </div>
        ) : (
          <div className="space-y-4">
            {providers
              .filter((p) => p.type === 'openai' || p.type === 'gemini' || p.type === 'elevenlabs')
              .map((p) => (
                <div key={p.id} className="p-4 rounded-xl bg-[#0D1728] border border-[#1E3250] space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-white">{p.name}</h4>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Current: <span className="font-mono text-slate-300">{p.keyMasked || 'None'}</span>
                      </p>
                    </div>
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-[#132238] border border-[#1E3250] text-slate-300">
                      {p.hasKey ? 'Configured' : 'Missing Key'}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="relative flex-1">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="password"
                        value={keys[p.id] || ''}
                        onChange={(e) => setKeys({ ...keys, [p.id]: e.target.value })}
                        placeholder="Paste new API key to update..."
                        className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white focus:outline-none focus:border-[#2585F5]"
                      />
                    </div>
                    <button
                      onClick={() => handleSaveKey(p)}
                      disabled={savingId === p.id || !keys[p.id]}
                      className="px-4 py-2 rounded-xl bg-[#2585F5] hover:bg-[#1B73DE] text-white text-xs font-semibold flex items-center gap-1.5 disabled:opacity-40"
                    >
                      {savingId === p.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                      Save
                    </button>
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  );
};
