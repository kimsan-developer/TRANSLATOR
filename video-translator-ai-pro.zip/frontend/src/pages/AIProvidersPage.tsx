import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { AIProvider } from '../types';
import { toast } from '../stores/toastStore';
import { Cpu, CheckCircle2, AlertCircle, RefreshCw, Key, Power, Play, Loader2 } from 'lucide-react';

export const AIProvidersPage: React.FC = () => {
  const [providers, setProviders] = useState<AIProvider[]>([]);
  const [loading, setLoading] = useState(true);
  const [testingId, setTestingId] = useState<string | null>(null);

  const fetchProviders = async () => {
    try {
      const res = await api.get('/providers');
      if (res.data.success) {
        setProviders(res.data.providers);
      }
    } catch {
      toast.error('Failed to load AI providers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProviders();
  }, []);

  const handleTestConnection = async (id: string) => {
    setTestingId(id);
    try {
      const res = await api.post(`/providers/${id}/test`);
      if (res.data.success) {
        toast.success(res.data.message || 'Connection verified successfully!');
      } else {
        toast.warning(res.data.message || 'Connection check failed');
      }
      fetchProviders();
    } catch (err: any) {
      toast.error('Test request failed');
    } finally {
      setTestingId(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1E3250]">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Cpu className="w-6 h-6 text-[#2585F5]" /> AI Provider Manager
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Centralized orchestration for local Faster-Whisper, Edge TTS, Google Gemini, OpenAI, and ElevenLabs
          </p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center p-12">
          <Loader2 className="w-8 h-8 text-[#2585F5] animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {providers.map((p) => (
            <div
              key={p.id}
              className="bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-base">{p.name}</h3>
                    {p.isDefault && (
                      <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-[#2585F5]/20 text-[#36B8F5] border border-[#2585F5]/30">
                        Default
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-medium">
                    {p.status === 'online' ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> Online
                      </span>
                    ) : p.status === 'unconfigured' ? (
                      <span className="text-amber-400 flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" /> Unconfigured
                      </span>
                    ) : (
                      <span className="text-rose-400 flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" /> Offline
                      </span>
                    )}
                  </div>
                </div>

                <div className="mt-4 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Engine Type:</span>
                    <span className="font-mono text-white capitalize">{p.type}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Selected Model:</span>
                    <span className="font-mono text-[#36B8F5]">{p.selectedModel || 'Auto'}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>API Key Status:</span>
                    <span className="font-mono text-slate-300">
                      {p.hasKey ? (p.keyMasked || '•••••••• (Encrypted)') : 'Not Required / Unset'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-[#1E3250] flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  {p.lastTestedAt ? `Tested: ${new Date(p.lastTestedAt).toLocaleDateString()}` : 'Not tested yet'}
                </span>

                <button
                  onClick={() => handleTestConnection(p.id)}
                  disabled={testingId === p.id}
                  className="px-4 py-2 rounded-xl bg-[#1E3250] hover:bg-[#2585F5] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  {testingId === p.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                  Test Connection
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
