import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useProjectStore } from '../stores/projectStore';
import { toast } from '../stores/toastStore';
import { Download, Film, CheckCircle2, Sliders, Play, Loader2 } from 'lucide-react';

export const VideoExportPage: React.FC = () => {
  const { currentProject } = useProjectStore();
  const [format, setFormat] = useState('mp4');
  const [resolution, setExportResolution] = useState('1080p');
  const [burnSubtitles, setBurnSubtitles] = useState(true);
  const [replaceAudio, setReplaceAudio] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [exportedFile, setExportedFile] = useState<string | null>(null);

  useEffect(() => {
    if (currentProject?.exportedVideoFile) {
      setExportedFile(currentProject.exportedVideoFile);
    }
  }, [currentProject]);

  const handleExport = async () => {
    if (!currentProject) return;
    setExporting(true);
    try {
      const res = await api.post('/export/start', {
        projectId: currentProject._id,
        format,
        resolution,
        burnSubtitles,
        replaceAudio,
      });
      if (res.data.success) {
        toast.info('FFmpeg video rendering job started in background');
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Export failed');
    } finally {
      setExporting(false);
    }
  };

  if (!currentProject) {
    return (
      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-12 text-center max-w-xl mx-auto my-12">
        <Film className="w-12 h-12 text-[#2585F5] mx-auto mb-3" />
        <h2 className="text-xl font-bold text-white">No Project Selected</h2>
        <p className="text-xs text-slate-400 mt-2">Select a project to render and export video.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <Download className="w-6 h-6 text-[#2585F5]" /> Video Export Studio
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          High-performance FFmpeg video encoding with hardcoded subtitles and audio mastering
        </p>
      </div>

      <div className="bg-[#132238] border border-[#1E3250] rounded-2xl p-6 shadow-xl space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Container Format</label>
            <select
              value={format}
              onChange={(e) => setFormat(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
            >
              <option value="mp4">MP4 (H.264 / AAC - Universal)</option>
              <option value="mkv">MKV (Matroska)</option>
              <option value="mov">MOV (Apple ProRes / QuickTime)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase">Resolution Target</label>
            <select
              value={resolution}
              onChange={(e) => setExportResolution(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#080F1D] border border-[#1E3250] text-xs text-white"
            >
              <option value="original">Original Resolution</option>
              <option value="1080p">1080p Full HD (1920x1080)</option>
              <option value="720p">720p HD (1280x720)</option>
            </select>
          </div>
        </div>

        <div className="space-y-2 p-4 rounded-xl bg-[#0D1728] border border-[#1E3250]">
          <label className="flex items-center gap-2 text-xs font-semibold text-white cursor-pointer">
            <input
              type="checkbox"
              checked={burnSubtitles}
              onChange={(e) => setBurnSubtitles(e.target.checked)}
              className="w-4 h-4 rounded text-[#2585F5]"
            />
            Hardcode / Burn Translated Subtitles onto Video
          </label>
          <label className="flex items-center gap-2 text-xs font-semibold text-white cursor-pointer">
            <input
              type="checkbox"
              checked={replaceAudio}
              onChange={(e) => setReplaceAudio(e.target.checked)}
              className="w-4 h-4 rounded text-[#2585F5]"
            />
            Replace / Mix Original Audio with Translated AI Voice
          </label>
        </div>

        <button
          onClick={handleExport}
          disabled={exporting}
          className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-bold shadow hover:brightness-110 flex items-center justify-center gap-2"
        >
          {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Film className="w-4 h-4" />}
          Render & Export Finished Video
        </button>

        {exportedFile && (
          <div className="p-4 rounded-xl bg-[#0D1728] border border-emerald-500/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <div>
                <h4 className="text-xs font-bold text-white">Finished Video Ready</h4>
                <p className="text-[11px] text-slate-400">Available for high-speed download</p>
              </div>
            </div>
            <a
              href={exportedFile}
              download
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold flex items-center gap-1.5 shadow"
            >
              <Download className="w-4 h-4" /> Download File
            </a>
          </div>
        )}
      </div>
    </div>
  );
};
