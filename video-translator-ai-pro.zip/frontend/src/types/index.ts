export interface User {
  id: string;
  name: string;
  email: string;
  role: 'superadmin' | 'admin' | 'user';
  avatar?: string;
  isActive: boolean;
  preferences?: {
    theme?: string;
    defaultSourceLang?: string;
    defaultTargetLang?: string;
  };
}

export interface SubtitleSegment {
  id: number;
  start: number; // in seconds
  end: number;   // in seconds
  text: string;
  originalText?: string;
  confidence?: number;
}

export interface Subtitle {
  _id: string;
  projectId: string;
  language: string;
  type: 'original' | 'translated';
  format: 'srt' | 'vtt';
  segments: SubtitleSegment[];
}

export interface VideoMetadata {
  _id: string;
  projectId: string;
  originalName: string;
  filename: string;
  path: string;
  size: number;
  duration: number;
  resolution: {
    width: number;
    height: number;
  };
  format: string;
  fps: number;
  bitrate?: number;
  thumbnailPath?: string;
}

export interface AudioTrack {
  _id: string;
  projectId: string;
  type: 'extracted' | 'tts' | 'cloned' | 'bg_music' | 'mixed';
  filename: string;
  path: string;
  duration: number;
  language?: string;
  voiceId?: string;
  volume: number;
  status: string;
}

export interface Project {
  _id: string;
  title: string;
  description?: string;
  userId: string;
  sourceLanguage: string;
  targetLanguage: string;
  status: 'draft' | 'uploaded' | 'transcribing' | 'translated' | 'dubbed' | 'completed' | 'failed';
  videoFile?: string;
  videoDuration?: number;
  thumbnail?: string;
  originalSubtitleId?: string | Subtitle;
  translatedSubtitleId?: string | Subtitle;
  generatedAudioFile?: string;
  exportedVideoFile?: string;
  currentStep: number;
  createdAt: string;
  updatedAt: string;
}

export interface ProcessingJob {
  _id: string;
  projectId: string | { _id: string; title: string };
  userId: string | { _id: string; name: string; email: string };
  type: 'transcription' | 'translation' | 'tts' | 'voice_clone' | 'sync' | 'export';
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  currentStep: string;
  logs: string[];
  error?: string;
  createdAt: string;
}

export interface AIProvider {
  id: string;
  name: string;
  type: 'openai' | 'gemini' | 'whisper' | 'edge-tts' | 'elevenlabs' | 'local';
  models: string[];
  selectedModel?: string;
  enabled: boolean;
  isDefault: boolean;
  status: 'online' | 'offline' | 'error' | 'unconfigured';
  lastTestedAt?: string;
  usageCount: number;
  hasKey: boolean;
  keyMasked?: string;
}

export interface VoiceProfile {
  _id: string;
  name: string;
  language: string;
  gender: 'male' | 'female' | 'neutral';
  samplePath: string;
  sampleDuration: number;
  provider: string;
  voiceId?: string;
  consentAgreed: boolean;
  status: string;
  createdAt: string;
}

export interface UsageRecord {
  _id: string;
  feature: string;
  provider: string;
  durationSeconds?: number;
  characterCount?: number;
  costEstimate: number;
  status: string;
  timestamp: string;
  projectId?: { _id: string; title: string };
}
