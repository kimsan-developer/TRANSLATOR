import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import { MainLayout } from '../layouts/MainLayout';
import { AuthLayout } from '../layouts/AuthLayout';

import { LoginPage } from '../pages/LoginPage';
import { RegisterPage } from '../pages/RegisterPage';
import { DashboardPage } from '../pages/DashboardPage';
import { ProjectsPage } from '../pages/ProjectsPage';
import { VideoTranslatorWizardPage } from '../pages/VideoTranslatorWizardPage';
import { SpeechToTextPage } from '../pages/SpeechToTextPage';
import { AITranslationPage } from '../pages/AITranslationPage';
import { SubtitleEditorPage } from '../pages/SubtitleEditorPage';
import { AIVoiceGeneratorPage } from '../pages/AIVoiceGeneratorPage';
import { VoiceCloningPage } from '../pages/VoiceCloningPage';
import { AudioSyncPage } from '../pages/AudioSyncPage';
import { VideoPreviewPage } from '../pages/VideoPreviewPage';
import { VideoExportPage } from '../pages/VideoExportPage';
import { AIProvidersPage } from '../pages/AIProvidersPage';
import { ApiSettingsPage } from '../pages/ApiSettingsPage';
import { UsageHistoryPage } from '../pages/UsageHistoryPage';
import { UserProfilePage } from '../pages/UserProfilePage';
import { AdminPanelPage } from '../pages/AdminPanelPage';

const ProtectedRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
  const { isAuthenticated } = useAuthStore();
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

export const AppRoutes: React.FC = () => {
  return (
    <Routes>
      {/* Auth routes */}
      <Route element={<AuthLayout />}>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
      </Route>

      {/* Main app layout */}
      <Route
        element={
          <ProtectedRoute>
            <MainLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/projects" element={<ProjectsPage />} />
        <Route path="/translator" element={<VideoTranslatorWizardPage />} />
        <Route path="/speech-to-text" element={<SpeechToTextPage />} />
        <Route path="/translation" element={<AITranslationPage />} />
        <Route path="/subtitles" element={<SubtitleEditorPage />} />
        <Route path="/voice-generator" element={<AIVoiceGeneratorPage />} />
        <Route path="/voice-cloning" element={<VoiceCloningPage />} />
        <Route path="/audio-sync" element={<AudioSyncPage />} />
        <Route path="/video-preview" element={<VideoPreviewPage />} />
        <Route path="/video-export" element={<VideoExportPage />} />
        <Route path="/providers" element={<AIProvidersPage />} />
        <Route path="/api-settings" element={<ApiSettingsPage />} />
        <Route path="/history" element={<UsageHistoryPage />} />
        <Route path="/profile" element={<UserProfilePage />} />
        <Route path="/admin" element={<AdminPanelPage />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
};
