import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../stores/authStore';
import { useProjectStore } from '../../stores/projectStore';
import { PlusCircle, LogOut, User, FolderPlus } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { user, logout } = useAuthStore();
  const { currentProject } = useProjectStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="h-16 bg-[#0D1728]/80 backdrop-blur-md border-b border-[#1E3250] px-6 flex items-center justify-between sticky top-0 z-40">
      {/* Left: Active Project Indicator */}
      <div className="flex items-center gap-4">
        {currentProject ? (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#132238] border border-[#1E3250]">
            <span className="text-xs text-slate-400 font-medium">Active Project:</span>
            <span className="text-xs font-semibold text-white max-w-[200px] truncate">
              {currentProject.title}
            </span>
            <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-[#2585F5]/20 text-[#36B8F5] border border-[#2585F5]/40">
              {currentProject.status}
            </span>
          </div>
        ) : (
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <span>No project selected</span>
            <Link
              to="/projects"
              className="text-[#36B8F5] hover:underline flex items-center gap-1 font-medium"
            >
              <FolderPlus className="w-3.5 h-3.5" /> Select or Create
            </Link>
          </div>
        )}
      </div>

      {/* Right: Quick actions & User menu */}
      <div className="flex items-center gap-4">
        <Link
          to="/translator"
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#2585F5] to-[#36B8F5] text-white text-xs font-semibold shadow-md shadow-[#2585F5]/30 hover:brightness-110 transition-all"
        >
          <PlusCircle className="w-4 h-4" />
          New Translation
        </Link>

        <div className="h-5 w-px bg-[#1E3250]" />

        {/* User Profile */}
        <div className="flex items-center gap-3">
          <Link
            to="/profile"
            className="flex items-center gap-2.5 text-xs font-medium text-slate-200 hover:text-white transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-[#1E3250] border border-[#2585F5]/40 flex items-center justify-center font-bold text-white uppercase text-xs">
              {user?.name ? user.name.substring(0, 2) : <User className="w-4 h-4" />}
            </div>
            <div className="hidden md:block text-left">
              <div className="font-semibold text-white leading-tight">{user?.name || 'User'}</div>
              <div className="text-[10px] text-slate-400 capitalize">{user?.role || 'Member'}</div>
            </div>
          </Link>

          <button
            onClick={handleLogout}
            title="Logout"
            className="p-2 text-slate-400 hover:text-rose-400 hover:bg-[#132238] rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
