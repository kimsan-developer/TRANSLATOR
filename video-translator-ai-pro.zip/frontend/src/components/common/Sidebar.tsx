import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  FolderKanban,
  Wand2,
  Mic,
  Languages,
  Subtitles,
  AudioWaveform,
  UserCheck,
  Sliders,
  PlaySquare,
  Download,
  Cpu,
  Key,
  History,
  User,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';

interface NavItem {
  to: string;
  label: string;
  icon: any;
  highlight?: boolean;
  adminOnly?: boolean;
}

interface NavSection {
  label: string;
  items: NavItem[];
}

export const Sidebar: React.FC = () => {
  const { user } = useAuthStore();
  const isAdmin = user?.role === 'admin' || user?.role === 'superadmin';

  const navSections: NavSection[] = [
    {
      label: 'WORKSPACE',
      items: [
        { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { to: '/projects', label: 'My Projects', icon: FolderKanban },
        { to: '/translator', label: 'Video Translator', icon: Wand2, highlight: true },
      ],
    },
    {
      label: 'AI PROCESSING',
      items: [
        { to: '/speech-to-text', label: 'Speech to Text', icon: Mic },
        { to: '/translation', label: 'AI Translation', icon: Languages },
        { to: '/subtitles', label: 'Subtitle Editor', icon: Subtitles },
        { to: '/voice-generator', label: 'AI Voice Generator', icon: AudioWaveform },
        { to: '/voice-cloning', label: 'Voice Cloning', icon: UserCheck },
      ],
    },
    {
      label: 'STUDIO & EXPORT',
      items: [
        { to: '/audio-sync', label: 'Audio Synchronization', icon: Sliders },
        { to: '/video-preview', label: 'Video Preview', icon: PlaySquare },
        { to: '/video-export', label: 'Video Export', icon: Download },
      ],
    },
    {
      label: 'AI & SYSTEM',
      items: [
        { to: '/providers', label: 'AI Providers', icon: Cpu },
        { to: '/api-settings', label: 'API Settings', icon: Key },
        { to: '/history', label: 'Usage History', icon: History },
        { to: '/profile', label: 'User Profile', icon: User },
        ...(isAdmin ? [{ to: '/admin', label: 'Admin Panel', icon: ShieldCheck, adminOnly: true }] : []),
      ],
    },
  ];

  return (
    <aside className="w-64 bg-[#0D1728] border-r border-[#1E3250] flex flex-col h-screen shrink-0 sticky top-0 overflow-y-auto">
      {/* Brand Logo */}
      <div className="p-5 border-b border-[#1E3250] flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#2585F5] to-[#36B8F5] flex items-center justify-center shadow-lg shadow-[#2585F5]/30">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <div className="text-base font-extrabold text-white tracking-tight flex items-center gap-1.5">
            TRANSLATOR <span className="text-[#36B8F5] text-xs font-black px-1.5 py-0.5 rounded bg-[#36B8F5]/10 border border-[#36B8F5]/30">PRO</span>
          </div>
          <div className="text-[11px] text-slate-400 font-medium">Enterprise AI Studio</div>
        </div>
      </div>

      {/* Nav List */}
      <div className="p-3 space-y-6 flex-1">
        {navSections.map((sec, idx) => (
          <div key={idx}>
            <div className="px-3 mb-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
              {sec.label}
            </div>
            <div className="space-y-1">
              {sec.items.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                        isActive
                          ? 'bg-[#2585F5] text-white shadow-md shadow-[#2585F5]/25 font-semibold'
                          : item.highlight
                          ? 'text-[#36B8F5] hover:bg-[#132238] hover:text-white'
                          : 'text-slate-300 hover:bg-[#132238] hover:text-white'
                      }`
                    }
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </NavLink>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer System Status */}
      <div className="p-4 border-t border-[#1E3250] bg-[#0A1220]">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            AI Engine Online
          </span>
          <span className="font-mono text-[10px] bg-[#132238] px-2 py-0.5 rounded text-slate-400 border border-[#1E3250]">v1.0.0</span>
        </div>
      </div>
    </aside>
  );
};
