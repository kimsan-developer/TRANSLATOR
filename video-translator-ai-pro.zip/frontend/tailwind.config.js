/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#080F1D',
        sidebar: '#0D1728',
        card: '#132238',
        cardHover: '#1B2C46',
        primary: {
          DEFAULT: '#2585F5',
          hover: '#1B73DE',
          light: '#4DA2FF',
        },
        secondary: {
          DEFAULT: '#36B8F5',
          hover: '#25A2DE',
        },
        text: '#F1F5F9',
        muted: '#94A3B8',
        border: '#1E3250',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
